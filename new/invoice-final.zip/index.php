<!DOCTYPE html>
<html>
<head>
<title>Invoice</title>
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="css/style.css">
<!------ Include the above in your HEAD tag ---------->
</head>
<body>
<div class="container login-container">
            <div class="row">
                <div class="col-md-6 login-form-1">
                    <h3>Support Admin</h3>
                    
                       
                      <center>   <div class="form-group">
                            
                            <a href="supper-admin/index.php" class="btnSubmit"  target="_blank" >For Login Click Here</a>
                        </div></center>
                        
                    
                </div>
                <div class="col-md-6 login-form-2">
                    <div class="login-logo">
                        <img src="https://image.ibb.co/n7oTvU/logo_white.png" alt=""/>
                    </div>
                    <h3>Mannage Admin</h3>
                        
                       <center>   <div class="form-group">
                            
                            <a href="manage-admin/index.php" class="btnSubmit"  target="_blank" >For Login Click Here</a>
                        </div></center>
                    </form>
                </div>
            </div>
        </div>
	</body>
</html>